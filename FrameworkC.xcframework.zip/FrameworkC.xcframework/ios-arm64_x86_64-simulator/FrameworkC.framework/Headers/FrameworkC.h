//
//  FrameworkC.h
//  FrameworkC
//
//  Created by Akshat Kukreti on 11/09/22.
//

#import <Foundation/Foundation.h>

//! Project version number for FrameworkC.
FOUNDATION_EXPORT double FrameworkCVersionNumber;

//! Project version string for FrameworkC.
FOUNDATION_EXPORT const unsigned char FrameworkCVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FrameworkC/PublicHeader.h>


