//
//  FrameworkD.h
//  FrameworkD
//
//  Created by Akshat Kukreti on 11/09/22.
//

#import <Foundation/Foundation.h>

//! Project version number for FrameworkD.
FOUNDATION_EXPORT double FrameworkDVersionNumber;

//! Project version string for FrameworkD.
FOUNDATION_EXPORT const unsigned char FrameworkDVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FrameworkD/PublicHeader.h>


